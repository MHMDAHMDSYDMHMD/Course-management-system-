﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using course_registration_system;
namespace project1
{
    public partial class showregistrertions : Form
    {
        public showregistrertions()
        {
            InitializeComponent();
        }

      

        private void showregistrertions_Load(object sender, EventArgs e)
        {
            this.CenterToScreen();



            MySqlConnection Database = new MySqlConnection("datasource=127.0.0.1;port=3306;username=root;password=;database=course registration system;");

            Database.Open();

            MySqlCommand cmd = new MySqlCommand("select * from registration", Database);
            int n = cmd.ExecuteNonQuery();
            //if (comboBox1.SelectedItem==null || textBox3 == null || textBox3.Text == "")
            //{
            //if (n > 0)
            //{
                string selectquery = "select * from registration";
                MySqlDataAdapter adpt = new MySqlDataAdapter(selectquery, Database);
                DataTable table = new DataTable();
                int i = adpt.Fill(table);
                dataGridView1.DataSource = table;
                if (i > 0) { MessageBox.Show("Data Selected Successfully."); }
            //}
            //}
            //else
            //{
            //    string comselect = comboBox1.SelectedItem.ToString();
            //    string txtselect = textBox3.Text;
            //    string selectquery = "select * from registration where " + comselect + "=" + txtselect;
            //    MySqlDataAdapter adpt = new MySqlDataAdapter(selectquery, Database);
            //    DataTable table = new DataTable();
            //    int i = adpt.Fill(table);
            //    dataGridView1.DataSource = table;
            //    if (i > 0) { MessageBox.Show("Data Selected Successfully."); }
            //}
        }
           
        //}

        private void addToolStripMenuItem_Click(object sender, EventArgs e)
        {
            addregistrartions a = new addregistrartions();
            a.ShowDialog();

        }

        private void addToolStripMenuItem_Click_1(object sender, EventArgs e)
        {

        }

        private void menuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void toolStripMenuItem1_Click(object sender, EventArgs e)
        {
            addregistrartions a = new addregistrartions();
            a.ShowDialog();
        }

        private void toolStripMenuItem2_Click(object sender, EventArgs e)
        {
    
        }

        private void udateToolStripMenuItem_Click(object sender, EventArgs e)
        {
            UDATEREISTIONS u = new UDATEREISTIONS();
            u.ShowDialog();
        }

        private void deleteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            delecteregistion d = new delecteregistion();
            d.ShowDialog();
        }


    }
}
