﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace course_registration_system
{
    public partial class del_course : Form
    {
        public del_course()
        {
            InitializeComponent();
        }

        private void udateToolStripMenuItem_Click(object sender, EventArgs e)
        {
            update_Course d = new update_Course();
            d.ShowDialog();
        }

        private void deleteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            del_course d = new del_course();
            d.ShowDialog();
        }

        private void showToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Course d = new Course();
            d.ShowDialog();
        }

        private void addToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Course d = new Course();
            d.ShowDialog();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int id = (int)numericUpDown2.Value;

            MySqlConnection Database = new MySqlConnection("datasource=127.0.0.1;port=3306;username=root;password=;database=course registration system;");
            Database.Open();
            MySqlCommand cmd1 = new MySqlCommand("delete from registrees where course_id= @id", Database);
            MySqlCommand cmd2 = new MySqlCommand("delete from registration where  course_id= @id", Database);
            MySqlCommand cmd3 = new MySqlCommand("delete from requirements where course_id= @id", Database);
            MySqlCommand cmd4 = new MySqlCommand("delete from course where course_id= @id", Database);

            cmd1.Parameters.AddWithValue("@id", id);
            cmd2.Parameters.AddWithValue("@id", id);
            cmd3.Parameters.AddWithValue("@id", id);
            cmd4.Parameters.AddWithValue("@id", id);

            cmd1.ExecuteNonQuery();
            cmd2.ExecuteNonQuery();
            cmd3.ExecuteNonQuery();
            cmd4.ExecuteNonQuery();

            MessageBox.Show("Removed successfully");

        }
    }
}
