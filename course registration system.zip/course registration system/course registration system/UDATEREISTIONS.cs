﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using project1;

namespace course_registration_system
{
    public partial class UDATEREISTIONS : Form
    {
        public UDATEREISTIONS()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (
                textBox1.Text == ""
                || textBox2.Text == ""
                || textBox3.Text == ""
                || dateTimePicker1.Value.ToString() == ""
                || textBox6.Text == ""
                || textBox7.Text == ""
                || textBox7.Text == ""
                || textBox1 == null
                || textBox2 == null
                || textBox3 == null
                || dateTimePicker1.Value == null
                || textBox6 == null
                || textBox7 == null
                || textBox7 == null
                || comboBox1.SelectedItem.ToString() == ""
               )
            { MessageBox.Show("Please Write Your Data"); }
            else
            {
                string fname = textBox1.Text;
                string lname = textBox2.Text;
                string addres = textBox3.Text;
                DateTime date = dateTimePicker1.Value;
                string age = textBox6.Text;
                int contact = Convert.ToInt32(textBox7.Text);
                int course = (int)numericUpDown1.Value;
                string gender = comboBox1.SelectedItem.ToString();
                int id = (int)numericUpDown2.Value;


                MySqlConnection Database = new MySqlConnection("datasource=127.0.0.1;port=3306;username=root;password=;database=course registration system;");
                Database.Open();
                MySqlCommand cmd = new MySqlCommand("update registration  set fname=@fname,lname=@lname,age=@age,gender=@gender,contact=@contact,address=@address,course_id=@course_id,date=@date where registration_id = @id", Database);
                 cmd.Parameters.AddWithValue("@id", id);
                 cmd.Parameters.AddWithValue("@fname", fname);
                 cmd.Parameters.AddWithValue("@lname", lname);
                 cmd.Parameters.AddWithValue("@age", age);
                 cmd.Parameters.AddWithValue("@gender", gender);
                 cmd.Parameters.AddWithValue("@date", date);
                 cmd.Parameters.AddWithValue("@contact", contact);
                 cmd.Parameters.AddWithValue("@address", addres);
                 cmd.Parameters.AddWithValue("@course_id", course);
                int i = cmd.ExecuteNonQuery();
                Database.Close();
                if (i > 0) { MessageBox.Show("Data Udated Successfully."); }
            }
        }

        private void addToolStripMenuItem_Click(object sender, EventArgs e)
        {
            addregistrartions a = new addregistrartions();
            a.ShowDialog();
        }

        private void showToolStripMenuItem_Click(object sender, EventArgs e)
        {
            showregistrertions s = new showregistrertions();
            s.ShowDialog();
        }

        private void deleteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            delecteregistion d = new delecteregistion();
            d.ShowDialog();
        }

        private void label10_Click(object sender, EventArgs e)
        {

        }

        private void numericUpDown2_ValueChanged(object sender, EventArgs e)
        {

        }

        private void udateToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }
    }
}
