﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
//using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace course_registration_system
{
    public partial class update_Course : Form
    {
        public update_Course()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string fname = textBox1.Text;
            string description = textBox2.Text;
            string subjects = textBox3.Text;
            string pre_requisites = textBox4.Text;
            int id = (int)numericUpDown1.Value;


            MySqlConnection Database = new MySqlConnection("datasource=127.0.0.1;port=3306;username=root;password=;database=course registration system;");
            Database.Open();
            MySqlCommand cmd = new MySqlCommand("update course  set name=@fname,description=@description,subjects=@subjects,pre-requisites=@pre_requisites where course_id = @id", Database);
            cmd.Parameters.AddWithValue("@id", id);
            cmd.Parameters.AddWithValue("@description", description);
            cmd.Parameters.AddWithValue("@subjects", subjects);
            cmd.Parameters.AddWithValue("@pre_requisites", pre_requisites);
            cmd.Parameters.AddWithValue("@fname", fname);
            int i = cmd.ExecuteNonQuery();
            Database.Close();
            if (i > 0) { MessageBox.Show("Data Udated Successfully."); }
        }

        private void udateToolStripMenuItem_Click(object sender, EventArgs e)
        {
            update_Course d = new update_Course();
            d.ShowDialog();
        }

        private void deleteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            del_course d = new del_course();
            d.ShowDialog();
        }

        private void showToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Course d = new Course();
            d.ShowDialog();
        }

        private void addToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Course d = new Course();
            d.ShowDialog();
        }
    }
}
