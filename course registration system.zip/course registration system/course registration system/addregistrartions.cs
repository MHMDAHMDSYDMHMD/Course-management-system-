﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using System.Threading;
using course_registration_system;
namespace project1
{
    public partial class addregistrartions : Form
    {
        public addregistrartions()
        {
            InitializeComponent();
        }
       //public static int global ;


        private void addToolStripMenuItem_Click(object sender, EventArgs e)
        {
            

        }

        private void showToolStripMenuItem_Click(object sender, EventArgs e)
        {
            showregistrertions s = new showregistrertions();
            s.ShowDialog();
        }

        private void deleteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
          
        }

        private void udateToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
        }

        private void menuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void addregistrartions_Load(object sender, EventArgs e)
        {
            this.CenterToScreen();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (
                textBox1.Text == ""
                || textBox2.Text == ""
                || textBox3.Text == ""
                || dateTimePicker1.Value.ToString() == ""
                || textBox6.Text == ""
                || textBox7.Text == ""
                || textBox7.Text == ""
                || textBox1 == null
                || textBox2 == null
                || textBox3 == null
                || dateTimePicker1.Value == null
                || textBox6 == null
                || textBox7 == null
                || textBox7 == null
                || comboBox1.SelectedItem.ToString() == ""
               )
            { MessageBox.Show("Please Write Your Data"); }
            else
            {
                string fname = textBox1.Text;
                string lname = textBox2.Text;
                string addres = textBox3.Text;
                DateTime date = dateTimePicker1.Value;
                string age = textBox6.Text;
                int contact = Convert.ToInt32(textBox7.Text);
                int course = (int)numericUpDown1.Value;

                string gender = comboBox1.SelectedItem.ToString();


                MySqlConnection scon = new MySqlConnection("datasource=127.0.0.1;port=3306;username=root;password=;database=course registration system;");
                scon.Open();
                MySqlCommand cmd = new MySqlCommand();
                cmd.Connection = scon;
                cmd.CommandText = "insert into registration values(@ID,@fname, @lname, @age,@gender, @address, @contact,@course_id,@date)";
                //int id = Interlocked.Increment(ref global);
                DataColumn dc = new DataColumn();

                dc.DataType = System.Type.GetType("System.Int32");
                dc.AutoIncrement = true;
                dc.AutoIncrementSeed = 100000;
                dc.AutoIncrementStep = 1;

                cmd.Parameters.AddWithValue("@ID", dc);
                cmd.Parameters.AddWithValue("@fname", fname);
                cmd.Parameters.AddWithValue("@lname", lname);
                cmd.Parameters.AddWithValue("@age", age);
                cmd.Parameters.AddWithValue("@gender", gender);
                cmd.Parameters.AddWithValue("@date", date);
                cmd.Parameters.AddWithValue("@contact", contact);
                cmd.Parameters.AddWithValue("@address", addres);
                cmd.Parameters.AddWithValue("@course_id", course);
                 
                int i = cmd.ExecuteNonQuery();
                scon.Close();
                if(i > 0)MessageBox.Show("Data Inserted Successfully.");

                
            }
        }

        private void showToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            showregistrertions s = new showregistrertions();
            s.ShowDialog();
        }

        private void addToolStripMenuItem_Click_1(object sender, EventArgs e)
        {

        }

        private void deleteToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            delecteregistion d = new delecteregistion();
            d.ShowDialog();
        }

        private void udateToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            UDATEREISTIONS u = new UDATEREISTIONS();
            u.ShowDialog();
        }
    }
}
