﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using course_registration_system;
using project1;

namespace course_registration_system
{
    public partial class delecteregistion : Form
    {
        public delecteregistion()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int id = (int)numericUpDown2.Value;

            MySqlConnection Database = new MySqlConnection("datasource=127.0.0.1;port=3306;username=root;password=;database=course registration system;");
            Database.Open();
            MySqlCommand cmd2 = new MySqlCommand("delete from registrees where registration_id= @id2", Database);
            MySqlCommand cmd1 = new MySqlCommand("delete from requirements where registration_id= @id1", Database);
            MySqlCommand cmd = new MySqlCommand("delete from registration where registration_id= @id", Database);

            cmd1.Parameters.AddWithValue("@id1", id);
            cmd2.Parameters.AddWithValue("@id2", id);
            cmd.Parameters.AddWithValue("@id", id);

            int n = cmd2.ExecuteNonQuery();
             n += cmd1.ExecuteNonQuery();
              n += cmd.ExecuteNonQuery();

            if (n > 2) { MessageBox.Show("Data Deleted Successfully."); }
        }

        private void addToolStripMenuItem_Click(object sender, EventArgs e)
        {
            addregistrartions a = new addregistrartions();
            a.ShowDialog();
        }

        private void showToolStripMenuItem_Click(object sender, EventArgs e)
        {
            showregistrertions s = new showregistrertions();
            s.ShowDialog();
        }

        private void udateToolStripMenuItem_Click(object sender, EventArgs e)
        {
            UDATEREISTIONS u = new UDATEREISTIONS();
            u.ShowDialog();
        }
    }
}
