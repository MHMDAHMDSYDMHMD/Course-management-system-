﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace course_registration_system
{
    public partial class registrees : Form
    {
        public registrees()
        {
            InitializeComponent();
        }

        private void registrees_Load(object sender, EventArgs e)
        {
            MySqlConnection con = new MySqlConnection("datasource=127.0.0.1;port=3306;username=root;password=;database=course registration system f;");
            con.Open();
            MySqlCommand com = new MySqlCommand("select * from registrees", con);

            MySqlDataAdapter m = new MySqlDataAdapter(com);
            DataTable dt = new DataTable();
            com.ExecuteNonQuery();
            m.Fill(dt);
            dataGridView1.DataSource = dt;
            con.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            MySqlConnection con = new MySqlConnection("datasource=127.0.0.1;port=3306;username=root;password=;database=course registration system;");
            con.Open();
            MySqlCommand com = new MySqlCommand("select * from registrees", con);

            MySqlDataAdapter m = new MySqlDataAdapter(com);
            DataTable dt = new DataTable();
            com.ExecuteNonQuery();
            m.Fill(dt);
            dataGridView1.DataSource = dt;
            con.Close();
            MessageBox.Show("sucs Select");
        }

        private void button1_Click(object sender, EventArgs e)
        {

            decimal registration_id = numericUpDown1.Value;
            decimal course_id = numericUpDown2.Value;
            decimal requirement_id = numericUpDown3.Value;
            DateTime date = dateTimePicker1.Value;

            MySqlConnection con = new MySqlConnection("datasource=127.0.0.1;port=3306;username=root;password=;database=course registration system;");
            con.Open();
            MySqlCommand com = new MySqlCommand("insert into registrees Values (@ID,@registration_id,@course_id,@requirement_id,@date)", con);

            DataColumn dc = new DataColumn();

            dc.DataType = System.Type.GetType("System.Int32");
            dc.AutoIncrement = true;
            dc.AutoIncrementSeed = 100000;
            dc.AutoIncrementStep = 1;

            com.Parameters.AddWithValue("@ID", dc);
            com.Parameters.AddWithValue("@registration_id", registration_id);
            com.Parameters.AddWithValue("@course_id", course_id);
            com.Parameters.AddWithValue("@requirement_id", requirement_id);
            com.Parameters.AddWithValue("@date", date);

            com.ExecuteNonQuery();
            con.Close();
            MessageBox.Show("inserted Select");
        }
    }
}
