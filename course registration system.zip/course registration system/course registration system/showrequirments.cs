﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace project1
{
    public partial class showrequirments : Form
    {
        public showrequirments()
        {
            InitializeComponent();
        }

        private void udateToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void showrequirments_Load(object sender, EventArgs e)
        {
            string ConnectionString;

            MySqlConnection Database;
            ConnectionString = "datasource=127.0.0.1;port=3306;username=root;password=;database=course registration system;";
            Database = new MySqlConnection(ConnectionString);
            Database.Open();

            MySqlCommand cmd = new MySqlCommand("select * from requirements", Database);
            int n = cmd.ExecuteNonQuery();
            
                if (n > 0)
                {
                    string selectquery = "select * from requirements";
                    MySqlDataAdapter adpt = new MySqlDataAdapter(selectquery, Database);
                    DataTable table = new DataTable();
                    int i = adpt.Fill(table);
                    dataGridView2.DataSource = table;
                    if (i > 0) { MessageBox.Show("Data Selected Successfully."); }
                }
            
            else
            {

                string selectquery = "select * from requirements ";
                MySqlDataAdapter adpt = new MySqlDataAdapter(selectquery, Database);
                DataTable table = new DataTable();
                int i = adpt.Fill(table);
                dataGridView2.DataSource = table;
                Database.Close();
                if (i > 0) { MessageBox.Show("Data Selected Successfully."); }
            }
        }
    }
}
