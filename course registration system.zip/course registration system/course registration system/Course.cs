﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;
using MySql.Data.MySqlClient;

namespace course_registration_system
{
    public partial class Course : Form
    {
        public Course()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string name = textBox1.Text;
            string description = textBox2.Text;
            string subjects = textBox3.Text;
            string pre_requisites = textBox4.Text;
            decimal registreesid = numericUpDown1.Value;

            MySqlConnection con = new MySqlConnection("datasource=127.0.0.1;port=3306;username=root;password=;database=course registration system;");
            con.Open();
            MySqlCommand com = new MySqlCommand("insert into course Values (@ID,@course_name,@course_description,@course_subjects,@course_pre_requisites,@course_registrees_id)", con);

            DataColumn dc = new DataColumn();

            dc.DataType = System.Type.GetType("System.Int32");
            dc.AutoIncrement = true;
            dc.AutoIncrementSeed = 100000;
            dc.AutoIncrementStep = 1;

            com.Parameters.AddWithValue("@ID", dc); 
            com.Parameters.AddWithValue("@course_name", name);
            com.Parameters.AddWithValue("@course_description", description);
            com.Parameters.AddWithValue("@course_subjects", subjects);
            com.Parameters.AddWithValue("@course_pre_requisites", pre_requisites);
            com.Parameters.AddWithValue("@course_registrees_id", registreesid);

            com.ExecuteNonQuery();
            con.Close();
            MessageBox.Show("Added successfully");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            MySqlConnection con = new MySqlConnection("datasource=127.0.0.1;port=3306;username=root;password=;database=course registration system ;");
            con.Open();
            MySqlCommand com = new MySqlCommand("select * from course", con);

            MySqlDataAdapter m = new MySqlDataAdapter(com);
            DataTable dt = new DataTable();
            com.ExecuteNonQuery();
            m.Fill(dt);
            dataGridView1.DataSource = dt;
            con.Close();
            MessageBox.Show("The data has been displayed");

        }

        private void button3_Click(object sender, EventArgs e)
        {
            MySqlConnection con = new MySqlConnection("datasource=127.0.0.1;port=3306;username=root;password=;database=course registration system;");
            con.Open();


            MySqlCommand com = new MySqlCommand("update course set name=@name,description=@description,subjects=@subjects,pre-requisites=@pre_requisites ,registrees_id=@registrees_id where Course_id=@course_id", con);
            com.Parameters.AddWithValue("@name", textBox1.Text);
            com.Parameters.AddWithValue("@description", textBox2.Text);
            com.Parameters.AddWithValue("@subjects", textBox3.Text);
            com.Parameters.AddWithValue("@pre_requisites", textBox4.Text);
            com.Parameters.AddWithValue("@registrees_id", numericUpDown1.Value);
            com.ExecuteNonQuery();

            con.Close();
            MessageBox.Show("sucs UPDATE");
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
                    }

        private void Course_Load(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void udateToolStripMenuItem_Click(object sender, EventArgs e)
        {
            update_Course d = new update_Course();
            d.ShowDialog();
        }

        private void deleteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            del_course d = new del_course();
            d.ShowDialog();
        }
    }
}
