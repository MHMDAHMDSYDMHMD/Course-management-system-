-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 17, 2023 at 12:13 AM
-- Server version: 10.4.25-MariaDB
-- PHP Version: 8.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `course registration system`
--

-- --------------------------------------------------------

--
-- Table structure for table `course`
--

CREATE TABLE `course` (
  `course_id` int(11) NOT NULL,
  `name` tinytext NOT NULL,
  `description` mediumtext NOT NULL,
  `subjects` text NOT NULL,
  `pre-requisites` text NOT NULL,
  `registrees_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `course`
--

INSERT INTO `course` (`course_id`, `name`, `description`, `subjects`, `pre-requisites`, `registrees_id`) VALUES
(1, 'english', 'aqwsedgtrshrfweA', 'AQSWGTRYJUDTRSFWEERGTY', 'QWERTYERGSWARTSEAW', 1),
(2, 'gfhjvbmn', 'ASDF', 'QWSRFG', 'SADF', 1),
(3, 'gfhjhjgjh', 'ghjnm,.m,/jb', 'grftyjhuil/,.', 'rtdyughjl', 1);

-- --------------------------------------------------------

--
-- Table structure for table `registrar`
--

CREATE TABLE `registrar` (
  `registrar_id` int(11) NOT NULL,
  `name` tinytext NOT NULL,
  `age` int(11) NOT NULL,
  `gender` tinytext NOT NULL,
  `contact` int(11) NOT NULL,
  `address` mediumtext NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `registrar`
--

INSERT INTO `registrar` (`registrar_id`, `name`, `age`, `gender`, `contact`, `address`, `username`, `password`) VALUES
(1, 'mhmd', 18, 'male', 1234567890, 'assiut', 'mhmd11', '123');

-- --------------------------------------------------------

--
-- Table structure for table `registration`
--

CREATE TABLE `registration` (
  `registration_id` int(11) NOT NULL,
  `fname` tinytext NOT NULL,
  `lname` tinytext NOT NULL,
  `age` int(11) NOT NULL,
  `gender` tinytext NOT NULL,
  `contact` int(11) NOT NULL,
  `address` tinytext NOT NULL,
  `course_id` int(11) NOT NULL,
  `date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `registration`
--

INSERT INTO `registration` (`registration_id`, `fname`, `lname`, `age`, `gender`, `contact`, `address`, `course_id`, `date`) VALUES
(3, 'asdf', 'afe', 12, 'Male', 98765432, 'qwedf', 2, '2023-04-15'),
(4, 'asdf', 'afe', 12, 'Male', 98765432, 'qwedf', 1, '2023-04-15');

-- --------------------------------------------------------

--
-- Table structure for table `registrees`
--

CREATE TABLE `registrees` (
  `registrees_id` int(11) NOT NULL,
  `registration_id` int(11) DEFAULT NULL,
  `course_id` int(11) DEFAULT NULL,
  `requirement_id` int(11) DEFAULT NULL,
  `date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `registrees`
--

INSERT INTO `registrees` (`registrees_id`, `registration_id`, `course_id`, `requirement_id`, `date`) VALUES
(1, 3, 3, 1, '2023-04-05'),
(3, 3, 2, 1, '2023-04-24');

-- --------------------------------------------------------

--
-- Table structure for table `requirements`
--

CREATE TABLE `requirements` (
  `requirements_id` int(11) NOT NULL,
  `registration_id` int(11) NOT NULL,
  `course_id` int(11) NOT NULL,
  `birth-certificate` tinytext NOT NULL,
  `previos-grades` tinytext NOT NULL,
  `good-moral` tinytext NOT NULL,
  `qualification` tinytext NOT NULL,
  `submission-date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `requirements`
--

INSERT INTO `requirements` (`requirements_id`, `registration_id`, `course_id`, `birth-certificate`, `previos-grades`, `good-moral`, `qualification`, `submission-date`) VALUES
(1, 4, 1, 'asdfghdzsAqCXZFDSa', 'WQERGTRH', 'SRFGTHYJNUMY', 'WERTGHJ', '2023-04-03'),
(2, 3, 2, 'sadfg', 'sqdf', 'sdf', 'wsdf', '2023-04-12');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `course`
--
ALTER TABLE `course`
  ADD PRIMARY KEY (`course_id`),
  ADD KEY `fk_cou_to_rgsr` (`registrees_id`);

--
-- Indexes for table `registrar`
--
ALTER TABLE `registrar`
  ADD PRIMARY KEY (`registrar_id`);

--
-- Indexes for table `registration`
--
ALTER TABLE `registration`
  ADD PRIMARY KEY (`registration_id`),
  ADD KEY `fk_reg_to_cou` (`course_id`);

--
-- Indexes for table `registrees`
--
ALTER TABLE `registrees`
  ADD PRIMARY KEY (`registrees_id`),
  ADD KEY `fk_reg_to_rgsr` (`registration_id`),
  ADD KEY `fk_reg_to_requi` (`requirement_id`),
  ADD KEY `course_id` (`course_id`);

--
-- Indexes for table `requirements`
--
ALTER TABLE `requirements`
  ADD PRIMARY KEY (`requirements_id`),
  ADD KEY `fk_req_to_rgsr` (`registration_id`),
  ADD KEY `fk_req_to_cou` (`course_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `course`
--
ALTER TABLE `course`
  MODIFY `course_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `registrar`
--
ALTER TABLE `registrar`
  MODIFY `registrar_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `registration`
--
ALTER TABLE `registration`
  MODIFY `registration_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `registrees`
--
ALTER TABLE `registrees`
  MODIFY `registrees_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `requirements`
--
ALTER TABLE `requirements`
  MODIFY `requirements_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `course`
--
ALTER TABLE `course`
  ADD CONSTRAINT `fk_cou_to_rgsr` FOREIGN KEY (`registrees_id`) REFERENCES `registrees` (`registrees_id`);

--
-- Constraints for table `registration`
--
ALTER TABLE `registration`
  ADD CONSTRAINT `fk_reg_to_cou` FOREIGN KEY (`course_id`) REFERENCES `course` (`course_id`);

--
-- Constraints for table `registrees`
--
ALTER TABLE `registrees`
  ADD CONSTRAINT `fk_reg_to_requi` FOREIGN KEY (`requirement_id`) REFERENCES `requirements` (`requirements_id`),
  ADD CONSTRAINT `fk_reg_to_rgsr` FOREIGN KEY (`registration_id`) REFERENCES `registration` (`registration_id`),
  ADD CONSTRAINT `registrees_ibfk_1` FOREIGN KEY (`course_id`) REFERENCES `course` (`course_id`);

--
-- Constraints for table `requirements`
--
ALTER TABLE `requirements`
  ADD CONSTRAINT `fk_req_to_cou` FOREIGN KEY (`course_id`) REFERENCES `course` (`course_id`),
  ADD CONSTRAINT `fk_req_to_rgsr` FOREIGN KEY (`registration_id`) REFERENCES `registration` (`registration_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
